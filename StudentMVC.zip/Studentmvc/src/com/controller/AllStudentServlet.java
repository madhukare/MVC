package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentDao;
import com.model.Student;


@WebServlet("/AllStudentServlet")
public class AllStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*int Id = Integer.parseInt(request.getParameter("sid"));
		String Name = request.getParameter("sname");
		String Batch = request.getParameter("sbatch");
		PrintWriter out = response.getWriter();*/
		String button = request.getParameter("bt");
		if (button.equals("AllStudents")) {
			response.setContentType("text/html");
			List<Student> stuList;
			try {
				stuList = StudentDao.getAllStudentDetails();
				request.setAttribute("slist", stuList);
				request.getRequestDispatcher("sList.jsp").forward(request, response);

			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
