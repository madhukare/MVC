package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentDao;
import com.model.Student;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int Id = Integer.parseInt(request.getParameter("sid"));
		String Name = request.getParameter("sname");
		String Batch = request.getParameter("sbatch");
		PrintWriter out = response.getWriter();
		String button = request.getParameter("bt");

		if(button.equals("Add")) {
			
			try {
				boolean IdExisted = StudentDao.ValidateStudentWithId(Id);
				/*request.setAttribute("idexists", IdExisted);
				request.getRequestDispatcher("slist.jsp").forward(request, response);*/
				if (IdExisted) {
					out.println("Already Id Exists");
					//response.sendRedirect("student.jsp");
				} else {
					if (StudentDao.addStudent(new Student(Id, Name, Batch))) {
						out.println("Added");
					} else {
						out.println("Not Added");
					}
				}
			} catch (ClassNotFoundException | SQLException e) {
			
				e.printStackTrace();
			}

		}else if(button.equals("Update")){
			
			try {
				if(StudentDao.ValidateStudentWithId(Id)){
				boolean update=StudentDao.updateStudentWithId(new Student(Id, Name, Batch));
				
				if(update){
					out.println("Updated Successfully");
				}else{
					out.println("Not updated");
					
				}
				}
			} catch (ClassNotFoundException | SQLException e) {
				
				e.printStackTrace();
			}
			
		}else if(button.equals("Delete")){
			
			try {
				if(StudentDao.ValidateStudentWithId(Id)){
					boolean delete=StudentDao.deleteStudentWithId(Id);
					if(delete){
						out.println("Deleted Successfully");
					}
					else{
						out.println("Not deleted");
					}
				}
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			
		}

	}

}
