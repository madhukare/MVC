package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Student;

public class StudentDao {
	public static List<Student> getAllStudentDetails() throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select * from student");
		ResultSet rs = ps.executeQuery();
		Student st = null;
		List<Student> sList = new ArrayList<Student>();
		while (rs.next()) {
			st = new Student(rs.getInt(1), rs.getString(2), rs.getString(3));
			sList.add(st);
		}

		return sList;
	}

	public static boolean ValidateStudentWithId(int Id) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select id from student where id=?");
		ps.setInt(1, Id);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			return true;
		}
		return false;
	}

	public static boolean addStudent(Student s) throws ClassNotFoundException, SQLException {

		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("insert into student values(?,?,?)");
		ps.setInt(1, s.getSid());
		ps.setString(2, s.getSname());
		ps.setString(3, s.getSbatch());
		int val = ps.executeUpdate();
		if (val != 0) {
			return true;
		}

		return false;

	}

	public static boolean updateStudentWithId(Student s) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("update student set name=?, batch=? where id=?");
		ps.setString(1, s.getSname());
		ps.setString(2, s.getSbatch());
		ps.setInt(3, s.getSid());
		int r = ps.executeUpdate();
		if (r != 0) {
			return true;
		}

		return false;

	}

	public static boolean deleteStudentWithId(int id) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("delete from student where id=?");
		ps.setInt(1, id);
		int r = ps.executeUpdate();
		if (r != 0) {
			return true;
		}

		return false;
	}
}
