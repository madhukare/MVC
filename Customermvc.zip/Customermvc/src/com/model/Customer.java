package com.model;

import java.sql.Date;

public class Customer {
	private String cname;
	private String cemail;
	private String cpwd;
	private Date dob;

	public Customer() {
		super();
	}

	public Customer(String cname, String cemail, String cpwd, Date dob) {
		super();
		this.cname = cname;
		this.cemail = cemail;
		this.cpwd = cpwd;
		this.dob = dob;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCemail() {
		return cemail;
	}

	public void setCemail(String cemail) {
		this.cemail = cemail;
	}

	public String getCpwd() {
		return cpwd;
	}

	public void setCpwd(String cpwd) {
		this.cpwd = cpwd;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

}
