package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CustomerDao;
import com.model.Customer;


@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String button=request.getParameter("bt");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		if(button.equals("Register")){
			String uname=request.getParameter("name");
			String uemail =request.getParameter("email");
			String upwd=request.getParameter("password");
			String udob=request.getParameter("dob");
			Date d=Date.valueOf(udob);
			
			try {
				boolean EmailExisted=CustomerDao.ValidateCustomerWithEmail(uemail);
				if(EmailExisted){
					out.println("Already Existed");
				}else if(CustomerDao.addCustomer(new Customer(uname, uemail, upwd, d))){
					out.println("Registered");
				}else{
					out.println("Not Registered");
				}
			} catch (ClassNotFoundException | SQLException e) {
				
				e.printStackTrace();
			}
						
		}else if(button.equals("Login")){
			String lemail=request.getParameter("lmail");
			String lpswd=request.getParameter("lpwd");
			try {
				if(CustomerDao.ValidateCustomerWithEmail(lemail)){
					String dbpwd=CustomerDao.getPasswordWithEmail(lemail);
					if(lpswd.equals(dbpwd)){
						request.getRequestDispatcher("login.jsp").forward(request, response);
					}else{
						out.println("Wrong Password");
						request.getRequestDispatcher("customer.jsp").include(request, response);
					}
				}else{
					out.println("Enter correct email");
					request.getRequestDispatcher("customer.jsp").include(request, response);
				}
			} catch (ClassNotFoundException | SQLException e) {
				
				e.printStackTrace();
			}
			
		}
	}

}
