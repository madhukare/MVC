package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Customer;

public class CustomerDao {

	public static boolean ValidateCustomerWithEmail(String email) throws ClassNotFoundException, SQLException {

		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("select email from customer");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			if (email.equals(rs.getString("email"))) {
				return true;
			}
		}
		return false;
	}

	public static boolean addCustomer(Customer cust) throws ClassNotFoundException, SQLException {
		Connection c = ConnectionUtility.getConnection();
		PreparedStatement ps = c.prepareStatement("insert into customer(name,email,pwd,DOB)values(?,?,aes_encrypt(?,'k1'),?)");
		ps.setString(1, cust.getCname());
		ps.setString(2, cust.getCemail());
		ps.setString(3, cust.getCpwd());
		ps.setDate(4, cust.getDob());
		int val = ps.executeUpdate();
		if (val != 0) {
			return true;
		}
		return false;
	}
	public static String getPasswordWithEmail(String email) throws ClassNotFoundException, SQLException{
		Connection c=ConnectionUtility.getConnection();
		PreparedStatement ps=c.prepareStatement("select aes_decrypt(pwd,'k1') from customer where email=?");
		ps.setString(1, email);
		ResultSet rs=ps.executeQuery();
		String pswd=null;
		if(rs.next()){
			pswd=rs.getString(1);
		}
		return pswd;
		
	}
}
